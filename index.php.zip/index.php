<?php require_once __DIR__ . '/php-graph-sdk-5.0.0/src/Facebook/autoload.php' ?>
	<?php 
	    switch ($_GET["type"]) {
	    	case 'Users':
	    		$q = $_GET["name"];
	    		$type = 'user';
	    		$fields = 'id,name,picture.width(700).height(700)';
	    		$param = compact('q','type','fields');
	    		break;
	    	case 'Pages':
	    		$q = $_GET["name"];
	    		$type = 'page';
	    		$fields = 'id,name,picture.width(700).height(700)';
	    		$param = compact('q','type','fields');
	    		break;
	    	case 'Events':
	    		$q = $_GET["name"];
	    		$type = 'event';
	    		$fields = 'id,name,picture.width(700).height(700),place';
	    		$param = compact('q','type','fields');
	    		break;
	    	case 'Groups':
	    		$q = $_GET["name"];
	    		$type = 'group';
	    		$fields = 'id,name,picture.width(700).height(700)';
	    		$param = compact('q','type','fields');
	    		break;
	    	case 'Places':
	    		$q = $_GET["name"];
	    		$type = 'place';
	    		$fields = 'id,name,picture.width(700).height(700)';
	    		$center = $_GET["location"];
	    		$param = compact('q','type','center','fields');
	    		break;
	    	case 'Details':
	    		$id = $_GET["name"];
	    		$param = array('fields' => "id,name,picture.width(700).height(700),albums.limit(5){name,photos.limit(2){name,picture}},posts.limit(5)");
	    		break;		
	    }

	$my_token = "EAAG0kRZCu96MBABYk8xgvJA1BNLqQIhuWi7HSQ5veGC8vsX0ZAwZBKLQ9exzspZCZAjPXVLkvN39K8HCjATVTy5lyd9d7fpAQaLeSfhcoAguPsjggDkKv9t7OBZAC9qTOSvLdvae414UzRZBP58GXm5Ln8dRGd4AigZD";
	$fb = new Facebook\Facebook([
	  'app_id' => '480010375722915',
	  'app_secret' => 'b72a42161233d6f6f16cc4429f909daf',
	  'default_graph_version' => 'v2.8',
	]);
	$fb->setDefaultAccessToken($my_token);
	if ($_GET["type"]=='Details')
		$request = $fb->request('GET',$id, $param);
	else
		$request = $fb->request('GET','/search', $param);
	$response = $fb->getClient()->sendRequest($request);
	$jsonstr = $response->getBody();
	if ($_GET["type"]=='Details')
		echo "detail_callback(".$jsonstr.");";	
	else
		echo "jsonp_callback(".$jsonstr.");";
	?>